<div class='width-50'>

<br/>

## Add application details

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/caseName/caseName1'>Case name</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/fl401TypeOfApplication/fl401TypeOfApplication1'>Type of application</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/withoutNoticeOrderDetails/withoutNoticeOrderDetails1'>Without notice order</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>## Add people to the case

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/applicantsDetails/applicantsDetails1'>Applicant details</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/respondentsDetails/respondentsDetails1'>Respondent details</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<<<<<<< HEAD
<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/fl401ApplicantFamilyDetails/fl401ApplicantFamilyDetails1'>Applicant's family</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>
=======
<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/fl401ApplicantFamilyDetails/fl401ApplicantFamilyDetails1'>Applicant's Family</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>
>>>>>>> 0a7eea67 (FL401 Submitted event for adding flags)

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Add case details

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/respondentRelationship/respondentRelationship1'>Relationship to respondent</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/respondentBehaviour/respondentBehaviour1'>Respondent's behaviour</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/fl401Home/fl401Home1'>The home</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Add additional information

<div class='panel panel-border-wide govuk-!-font-size-16'>Only complete if relevant</div>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/otherProceedings/otherProceedings1'>Other proceedings</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/attendingTheHearing/attendingTheHearing1'>Attending the hearing</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/welshLanguageRequirements/welshLanguageRequirements1'>Welsh language requirements</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Upload documents

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/uploadDocuments/uploadDocuments1'>Upload documents</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## View PDF application

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/viewPdfDocument/viewPdfDocument1'>View PDF application</a>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/statementOfTruthAndSubmit/statementOfTruthAndSubmit1'>Statement of truth and submit</a><img align='right' height='25px' src='https://raw.githubusercontent.com/hmcts/prl-cos-api/master/resources/not-started.png' title='Not started'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

</div>

<details class='govuk-details'>

<summary class='govuk-details__summary'>

<span class='govuk-details__summary-text'>

Why can't I submit my application?

</span>

</summary>

<div class='govuk-details__text'>

Add Without Notice Order details in <a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/withoutNoticeOrderDetails/withoutNoticeOrderDetails1'>Without notice order</a>

Add applicant details in <a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/applicantsDetails/applicantsDetails1'>Applicant details</a>

Add details about relationship to respondent in <a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/respondentRelationship/respondentRelationship1'>Relationship to respondent</a>

Add details about applicant's family in <a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/fl401ApplicantFamilyDetails/fl401ApplicantFamilyDetails1'>Applicant's family</a>

Add respondent details in <a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/respondentsDetails/respondentsDetails1'>Respondent details</a>

</div>

</details>
