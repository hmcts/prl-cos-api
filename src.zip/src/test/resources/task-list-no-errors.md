<div class='width-50'>

<br/>

## Add application details / Ychwanegu manylion y cais

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/selectApplicationType/selectApplicationType1'>Type of application / Math o gais</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/hearingUrgency/hearingUrgency1'>Hearing urgency / Pa mor frys yw’r cais</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Add people to the case / Ychwanegu pobl i’r achos

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/applicantsDetails/applicantsDetails1'>Applicant details / Manylion y ceisydd</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/childDetails/childDetails1'>Child details / Manylion y plentyn</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/respondentsDetails/respondentsDetails1'>Respondent details / Manylion yr atebydd</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Add required details / Ychwanegu manylion angenrheidiol

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/allegationsOfHarm/allegationsOfHarm1'>Allegations of harm / Honiadau o niwed</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHin-progress.png' title='In progress / Ar y gweill'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## MIAM details / Manylion MIAM

<div class='panel panel-border-wide govuk-!-font-size-16'>MIAM section is optional for final submit, if a consent order is uploaded and mandatory otherwise.<br/>Mae llenwi’r adran Cyfarfod Asesu a Gwybodaetham Gyfryngu (MIAM) yn ddewisol os bydd gorchymyn cydsynio’n cael ei uwchlwytho wrth gyflwyno’r cais terfynol. Fel arall mae’n rhaid ei llenwi.</div>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/miam/miam1'>MIAM / MIAM</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Add additional information / Ychwanegu gwybodaeth ychwanegol

<div class='panel panel-border-wide govuk-!-font-size-16'>Only complete if relevant / Llenwch yr adran hon dim ond os yw’n berthnasol</div>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/otherPeopleInTheCase/otherPeopleInTheCase1'>Other people in the case / Pobl eraill yn yr achos</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/otherProceedings/otherProceedings1'>Other proceedings / Achosion eraill</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/attendingTheHearing/attendingTheHearing1'>Attending the hearing / Mynychu’r gwrandawiad</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/internationalElement/internationalElement1'>International element / Elfen ryngwladol</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHfinished.png' title='Finished / Wedi gorffen'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/litigationCapacity/litigationCapacity1'>Litigation capacity / Capasiti cyfreitha</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHfinished.png' title='Finished / Wedi gorffen'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/welshLanguageRequirements/welshLanguageRequirements1'>Welsh language requirements / Gofynion o ran yr iaith Gymraeg</a><img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHnot-started.png' title='Not started / Heb ddechrau'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## View PDF application / Gweld y cais PDF

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<a href='/cases/case-details/${[CASE_REFERENCE]}/trigger/viewPdfDocument/viewPdfDocument1'>View PDF application / Gweld y cais PDF</a>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

<br/>

## Submit and pay / Cyflwyno a thalu

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

Submit and pay / Cyflwyno a thalu<img align='right' height='25px' src='NO IMAGE URL IN THIS BRANCHcannot-start-yet.png' title='Cannot start yet / Methu dechrau eto'/>

<hr class='govuk-!-margin-top-3 govuk-!-margin-bottom-2'/>

</div>
