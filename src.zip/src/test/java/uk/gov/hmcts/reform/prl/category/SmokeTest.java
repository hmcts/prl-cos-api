package uk.gov.hmcts.reform.prl.category;

public interface SmokeTest { /* category marker */ }
