package uk.gov.hmcts.reform.prl.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Qualifier;
import uk.gov.hmcts.reform.ccd.client.model.CallbackRequest;
import uk.gov.hmcts.reform.ccd.client.model.CaseDetails;
import uk.gov.hmcts.reform.prl.constants.PrlAppsConstants;
import uk.gov.hmcts.reform.prl.enums.State;
import uk.gov.hmcts.reform.prl.enums.YesNoDontKnow;
import uk.gov.hmcts.reform.prl.enums.YesOrNo;
import uk.gov.hmcts.reform.prl.mapper.citizen.confidentialdetails.ConfidentialDetailsMapper;
import uk.gov.hmcts.reform.prl.models.Address;
import uk.gov.hmcts.reform.prl.models.Element;
import uk.gov.hmcts.reform.prl.models.Organisation;
import uk.gov.hmcts.reform.prl.models.caseaccess.OrganisationPolicy;
import uk.gov.hmcts.reform.prl.models.caseflags.Flags;
import uk.gov.hmcts.reform.prl.models.common.dynamic.DynamicList;
import uk.gov.hmcts.reform.prl.models.complextypes.Child;
import uk.gov.hmcts.reform.prl.models.complextypes.ChildDetailsRevised;
import uk.gov.hmcts.reform.prl.models.complextypes.OtherPersonWhoLivesWithChild;
import uk.gov.hmcts.reform.prl.models.complextypes.PartyDetails;
import uk.gov.hmcts.reform.prl.models.complextypes.citizen.Response;
import uk.gov.hmcts.reform.prl.models.complextypes.citizen.documents.ResponseDocuments;
import uk.gov.hmcts.reform.prl.models.complextypes.citizen.response.confidentiality.KeepDetailsPrivate;
import uk.gov.hmcts.reform.prl.models.complextypes.refuge.RefugeConfidentialDocuments;
import uk.gov.hmcts.reform.prl.models.documents.Document;
import uk.gov.hmcts.reform.prl.models.dto.ccd.Barrister;
import uk.gov.hmcts.reform.prl.models.dto.ccd.CaseData;
import uk.gov.hmcts.reform.prl.models.dto.ccd.CitizenResponseDocuments;
import uk.gov.hmcts.reform.prl.models.dto.ccd.RespondentC8Document;
import uk.gov.hmcts.reform.prl.models.language.DocumentLanguage;
import uk.gov.hmcts.reform.prl.models.refuge.RefugeConfidentialDocumentsRecord;
import uk.gov.hmcts.reform.prl.services.c100respondentsolicitor.C100RespondentSolicitorService;
import uk.gov.hmcts.reform.prl.services.caseflags.PartyLevelCaseFlagsService;
import uk.gov.hmcts.reform.prl.services.document.DocumentGenService;
import uk.gov.hmcts.reform.prl.services.noticeofchange.NoticeOfChangePartiesService;
import uk.gov.hmcts.reform.prl.services.tab.summary.CaseSummaryTabService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.gov.hmcts.reform.prl.constants.PrlAppsConstants.C100_CASE_TYPE;
import static uk.gov.hmcts.reform.prl.constants.PrlAppsConstants.FL401_CASE_TYPE;
import static uk.gov.hmcts.reform.prl.enums.Gender.female;
import static uk.gov.hmcts.reform.prl.enums.LiveWithEnum.anotherPerson;
import static uk.gov.hmcts.reform.prl.enums.OrderTypeEnum.childArrangementsOrder;
import static uk.gov.hmcts.reform.prl.enums.RelationshipsEnum.father;
import static uk.gov.hmcts.reform.prl.enums.RelationshipsEnum.specialGuardian;
import static uk.gov.hmcts.reform.prl.enums.noticeofchange.SolicitorRole.Representing.CARESPONDENT;
import static uk.gov.hmcts.reform.prl.services.UpdatePartyDetailsService.HISTORICAL_DOC_TO_RETAIN_FOR_EVENTS;
import static uk.gov.hmcts.reform.prl.services.c100respondentsolicitor.C100RespondentSolicitorService.IS_CONFIDENTIAL_DATA_PRESENT;
import static uk.gov.hmcts.reform.prl.utils.ElementUtils.element;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class UpdatePartyDetailsServiceTest {

    public static final String BEARER_TOKEN = "Bearer token";
    @Mock
    NoticeOfChangePartiesService noticeOfChangePartiesService;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    ConfidentialDetailsMapper confidentialDetailsMapper;

    @Mock
    C100RespondentSolicitorService c100RespondentSolicitorService;

    @Mock
    DocumentLanguageService documentLanguageService;

    @Mock
    DocumentGenService documentGenService;

    @Mock
    PartyLevelCaseFlagsService partyLevelCaseFlagsService;

    @Mock
    @Qualifier("caseSummaryTab")
    CaseSummaryTabService caseSummaryTabService;

    @Mock
    ConfidentialityTabService confidentialityTabService;

    @Mock
    ConfidentialityC8RefugeService confidentialityC8RefugeService;

    @InjectMocks
    UpdatePartyDetailsService updatePartyDetailsService;

    @Mock
    ManageOrderService manageOrderService;

    @Mock
    C8ArchiveService c8ArchiveService;

    @Mock
    CaseNameService caseNameService;

    @Test
    void updateApplicantAndChildNames() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant1).build();
        List<Element<PartyDetails>> applicantList = Collections.singletonList(wrappedApplicant);

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .isAtAddressLessThan5YearsWithDontKnow(YesNoDontKnow.yes)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole(null).organisation(null).build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantList)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();

        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, "");
        verify(caseNameService).setFinalCaseName(anyMap(), any(CaseData.class));
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertNotNull(nocMap);

    }

    @Test
    void updateApplicantsAddressInCitizenResponseFl401() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.Yes)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails applicantUpdated = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .isAtAddressLessThan5YearsWithDontKnow(YesNoDontKnow.yes)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole(null).organisation(null).build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.FL401_CASE_TYPE)
            .applicantsFL401(applicant1)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());

        CaseData caseDataUpdated1 = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.FL401_CASE_TYPE)
            .applicantsFL401(applicantUpdated)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMapUpdated = caseDataUpdated1.toMap(new ObjectMapper());

        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .eventId("amendApplicantsDetails")
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMapUpdated)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        when(objectMapper.convertValue(stringObjectMapUpdated, CaseData.class)).thenReturn(caseDataUpdated1);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, "");
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
    }

    @Test
    void updateApplicantsAddressInCitizenResponse() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.Yes)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant1).build();
        List<Element<PartyDetails>> applicantList = Collections.singletonList(wrappedApplicant);

        PartyDetails applicantUpdated = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedApplicantUpdated = Element.<PartyDetails>builder().value(applicantUpdated).build();
        List<Element<PartyDetails>> applicantListUpdated = Collections.singletonList(wrappedApplicantUpdated);

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .isAtAddressLessThan5YearsWithDontKnow(YesNoDontKnow.yes)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole(null).organisation(null).build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantList)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());

        CaseData caseDataUpdated1 = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantListUpdated)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMapUpdated = caseDataUpdated1.toMap(new ObjectMapper());

        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .eventId("amendApplicantsDetails")
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMapUpdated)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        when(objectMapper.convertValue(stringObjectMapUpdated, CaseData.class)).thenReturn(caseDataUpdated1);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, "");
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertNotNull(nocMap);
    }

    @Test
    void updateApplicantsPhoneInCitizenResponse() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.Yes)
            .response(Response.builder().keepDetailsPrivate(KeepDetailsPrivate.builder().build()).build())
            .build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant1).build();
        List<Element<PartyDetails>> applicantList = Collections.singletonList(wrappedApplicant);

        PartyDetails applicantUpdated = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedApplicantUpdated = Element.<PartyDetails>builder().value(applicantUpdated).build();
        List<Element<PartyDetails>> applicantListUpdated = Collections.singletonList(wrappedApplicantUpdated);

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .isAtAddressLessThan5YearsWithDontKnow(YesNoDontKnow.yes)
            .response(Response.builder().keepDetailsPrivate(KeepDetailsPrivate.builder().build()).build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole(null).organisation(null).build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantList)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());

        CaseData caseDataUpdated1 = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantListUpdated)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMapUpdated = caseDataUpdated1.toMap(new ObjectMapper());

        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .eventId("amendApplicantsDetails")
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMapUpdated)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        when(objectMapper.convertValue(stringObjectMapUpdated, CaseData.class)).thenReturn(caseDataUpdated1);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, "");
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertNotNull(nocMap);
    }

    @Test
    void updateApplicantsEmailInCitizenResponse() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .isEmailAddressConfidential(YesOrNo.Yes)
            .response(Response.builder().build())
            .build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant1).build();
        List<Element<PartyDetails>> applicantList = Collections.singletonList(wrappedApplicant);

        PartyDetails applicantUpdated = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isEmailAddressConfidential(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedApplicantUpdated = Element.<PartyDetails>builder().value(applicantUpdated).build();
        List<Element<PartyDetails>> applicantListUpdated = Collections.singletonList(wrappedApplicantUpdated);

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .isAtAddressLessThan5YearsWithDontKnow(YesNoDontKnow.yes)
            .response(Response.builder().keepDetailsPrivate(KeepDetailsPrivate.builder().build()).build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole(null).organisation(null).build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantList)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());

        CaseData caseDataUpdated1 = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantListUpdated)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMapUpdated = caseDataUpdated1.toMap(new ObjectMapper());

        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .eventId("amendApplicantsDetails")
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMapUpdated)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        when(objectMapper.convertValue(stringObjectMapUpdated, CaseData.class)).thenReturn(caseDataUpdated1);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, "");
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertNotNull(nocMap);
    }

    @Test
    void newApplicantAdded() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .isEmailAddressConfidential(YesOrNo.Yes)
            .response(Response.builder().build())
            .build();
        PartyDetails applicant2 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .isEmailAddressConfidential(YesOrNo.Yes)
            .response(Response.builder().build())
            .build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant1).build();
        Element<PartyDetails> wrappedApplicant2 = Element.<PartyDetails>builder().value(applicant2).build();
        List<Element<PartyDetails>> applicantList = new ArrayList<>();
        applicantList.add(wrappedApplicant);
        applicantList.add(wrappedApplicant2);

        PartyDetails applicantUpdated = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isEmailAddressConfidential(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedApplicantUpdated = Element.<PartyDetails>builder().value(applicantUpdated).build();
        List<Element<PartyDetails>> applicantListUpdated = Collections.singletonList(wrappedApplicantUpdated);

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .isAtAddressLessThan5YearsWithDontKnow(YesNoDontKnow.yes)
            .response(Response.builder().keepDetailsPrivate(KeepDetailsPrivate.builder().build()).build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole(null).organisation(null).build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantList)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());

        CaseData caseDataUpdated1 = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantListUpdated)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .children(listOfChildren)
            .build();
        Map<String, Object> stringObjectMapUpdated = caseDataUpdated1.toMap(new ObjectMapper());

        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .eventId("applicantsDetails")
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMapUpdated)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        when(objectMapper.convertValue(stringObjectMapUpdated, CaseData.class)).thenReturn(caseDataUpdated1);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, "");
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertNotNull(nocMap);
    }

    @Test
    void updateApplicantAndChildNamesC100withNoApplicants() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(null)
            .children(null)
            .build();

        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();

        Map<String, Object> nocMap = Map.of("some", "stuff");

        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertNotNull(caseDataUpdated.get("applicantName"));
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));

    }

    @Test
    void updateApplicantAndChildNamesFL401() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");

        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.no)
            .response(Response.builder().build())
            .build();
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.FL401_CASE_TYPE)
            .applicantsFL401(applicant1)
            .respondentsFL401(respondent1)
            .build();

        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();

        Map<String, Object> nocMap = Map.of("some", "stuff");

        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertNotNull(caseDataUpdated.get("applicantName"));
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));

    }

    @Test
    void updateApplicantAndChildNamesFl401() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        caseDataUpdated.put("respondentName", "test1 test22");

        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.FL401_CASE_TYPE)
            .applicantsFL401(applicant1)
            .respondentsFL401(respondent1)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();

        Map<String, Object> nocMap = Map.of("some", "stuff");

        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertEquals("test1 test22", caseDataUpdated.get("respondentName"));

    }

    @Test
    void testCaseFlagFl401() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantsFL401", "test applicant");
        caseDataUpdated.put("respondentsFL401", "test respondent");
        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("applicant")
            .lastName("lastName")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent")
            .lastName("lastName")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();

        Address address = Address.builder()
            .addressLine1("address")
            .postTown("London")
            .build();

        OtherPersonWhoLivesWithChild personWhoLivesWithChild = OtherPersonWhoLivesWithChild.builder()
            .isPersonIdentityConfidential(YesOrNo.Yes).relationshipToChildDetails("test")
            .firstName("test First Name").lastName("test Last Name").address(address).build();

        Element<OtherPersonWhoLivesWithChild> wrappedList = Element.<OtherPersonWhoLivesWithChild>builder().value(
            personWhoLivesWithChild).build();
        List<Element<OtherPersonWhoLivesWithChild>> listOfOtherPersonsWhoLivedWithChild = Collections.singletonList(
            wrappedList);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .personWhoLivesWithChild(listOfOtherPersonsWhoLivedWithChild)
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.FL401_CASE_TYPE)
            .applicantsFL401(applicant1)
            .respondentsFL401(respondent1)
            .children(listOfChildren)
            .childrenKnownToLocalAuthority(YesNoDontKnow.no)
            .build();

        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();

        Map<String, Object> nocMap = Map.of("some", "stuff");
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);

        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);

        PartyDetails applicantsFL401 = PartyDetails.builder()
            .firstName("test")
            .lastName("applicant")
            .partyLevelFlag(Flags.builder()
                                .partyName("appl party")
                                .build())
            .build();

        PartyDetails respondentsFL401 = PartyDetails.builder()
            .firstName("test")
            .lastName("respondent")
            .partyLevelFlag(Flags.builder()
                                .partyName("resp party")
                                .build())
            .build();

        assertEquals("appl party", applicantsFL401.getPartyLevelFlag().getPartyName());
        assertEquals("resp party", respondentsFL401.getPartyLevelFlag().getPartyName());
    }


    @Test
    void testCaseFlagApplicantsC100() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        caseDataUpdated.put("respondentName", "test1 test22");
        PartyDetails applicant = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .isAtAddressLessThan5Years(YesOrNo.Yes)
            .build();

        PartyDetails applicant1 = PartyDetails.builder()
            .firstName("applicant2")
            .lastName("lastname")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .isAtAddressLessThan5Years(YesOrNo.Yes)
            .build();

        Element<PartyDetails> wrappedApplicant1 = Element.<PartyDetails>builder().value(applicant).build();
        Element<PartyDetails> wrappedApplicant2 = Element.<PartyDetails>builder().value(applicant1).build();

        List<Element<PartyDetails>> applicantList = new ArrayList<>();
        applicantList.add(wrappedApplicant1);
        applicantList.add(wrappedApplicant2);

        PartyDetails respondent = PartyDetails.builder()
            .firstName("test1")
            .lastName("test22")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .canYouProvidePhoneNumber(YesOrNo.Yes)
            .isCurrentAddressKnown(YesOrNo.Yes)
            .isAtAddressLessThan5Years(YesOrNo.Yes)
            .isDateOfBirthKnown(YesOrNo.Yes)
            .isPlaceOfBirthKnown(YesOrNo.Yes)
            .response(Response.builder().build())
            .doTheyHaveLegalRepresentation(YesNoDontKnow.yes)
            .build();

        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("test")
            .lastName("lastname")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .isCurrentAddressKnown(YesOrNo.No)
            .isAtAddressLessThan5Years(YesOrNo.No)
            .isDateOfBirthKnown(YesOrNo.No)
            .isPlaceOfBirthKnown(YesOrNo.No)
            .doTheyHaveLegalRepresentation(YesNoDontKnow.no)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().value(respondent1).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);
        respondentList.add(wrappedRespondent2);

        caseDataUpdated.put("applicants", "applicantList");
        OrganisationPolicy organisationPolicy = OrganisationPolicy.builder().orgPolicyReference("12345")
            .orgPolicyCaseAssignedRole("[ApplicantSolicitor]").organisation(Organisation.builder().build()).build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantList)
            .respondents(respondentList)
            .applicantOrganisationPolicy(organisationPolicy)
            .build();

        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();

        Map<String, Object> nocMap = Map.of("some", "stuff",
                                            "applicantOrganisationPolicy", organisationPolicy
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);

        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertEquals("test1 test22", caseDataUpdated.get("applicantName"));
        assertNotNull(caseDataUpdated.get("applicants"));
    }


    @Test
    void testCaseFlagRespondentsC100() {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        caseDataUpdated.put("respondentName", "respondent2 lastname222");
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().value(respondent2).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);
        respondentList.add(wrappedRespondent2);

        Child child = Child.builder()
            .firstName("Test")
            .lastName("Name")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChildren = Element.<Child>builder().value(child).build();
        List<Element<Child>> listOfChildren = Collections.singletonList(wrappedChildren);


        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondents(respondentList)
            .children(listOfChildren)
            .childrenKnownToLocalAuthority(YesNoDontKnow.no)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);

        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .caseDetailsBefore(CaseDetails.builder().id(123L).data(stringObjectMap).build())
            .build();
        DocumentLanguage documentLanguage = DocumentLanguage.builder().isGenEng(true).isGenWelsh(true).build();
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertNotNull("respondents");
    }

    @Test
    void testC8GenerateForRespondentsC100() throws Exception {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        caseDataUpdated.put("respondentName", "respondent2 lastname222");
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.Yes)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().id(UUID.randomUUID()).value(
            respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().id(UUID.randomUUID()).value(
            respondent2).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);
        respondentList.add(wrappedRespondent2);

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondents(respondentList)
            .respondentC8Document(RespondentC8Document.builder()
                                      .respondentAc8Documents(List
                                                                  .of(Element.<ResponseDocuments>builder().build()))
                                      .build())
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);

        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, true);
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        when(c100RespondentSolicitorService.populateDataMap(Mockito.any(), Mockito.any(), Mockito.anyString()))
            .thenReturn(dataMap);
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .build();
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertNotNull("respondents");
    }

    @Test
    void testC8GenerateForSixRespondentsC100() throws Exception {

        Map<String, Object> caseDataUpdated = new HashMap<>();
        caseDataUpdated.put("applicantName", "test1 test22");
        caseDataUpdated.put("respondentName", "respondent2 lastname222");
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .canYouProvideEmailAddress(YesOrNo.No)
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .isAddressConfidential(YesOrNo.Yes)
            .isCurrentAddressKnown(YesOrNo.Yes)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().keepDetailsPrivate(KeepDetailsPrivate.builder().build()).build())
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isAddressConfidential(YesOrNo.No)
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();
        PartyDetails respondent3 = PartyDetails.builder()
            .firstName("respondent3")
            .lastName("lastname333")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isAddressConfidential(YesOrNo.No)
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();
        PartyDetails respondent4 = PartyDetails.builder()
            .firstName("respondent4")
            .lastName("lastname444")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .response(Response.builder().build())
            .build();
        PartyDetails respondent5 = PartyDetails.builder()
            .firstName("respondent5")
            .lastName("lastname555")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .response(Response.builder().build())
            .build();
        PartyDetails respondent6 = PartyDetails.builder()
            .firstName("respondent6")
            .lastName("lastname666")
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isEmailAddressConfidential(YesOrNo.Yes)
            .email("resp1@test.com")
            .address(Address.builder().addressLine1("addressLin1").build())
            .phoneNumber("0123456789")
            .isPhoneNumberConfidential(YesOrNo.Yes)
            .canYouProvidePhoneNumber(YesOrNo.Yes)
            .response(Response.builder().build())
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder()
            .id(UUID.randomUUID()).value(respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder()
            .id(UUID.randomUUID()).value(respondent2).build();
        Element<PartyDetails> wrappedRespondent3 = Element.<PartyDetails>builder()
            .id(UUID.randomUUID()).value(respondent3).build();
        Element<PartyDetails> wrappedRespondent4 = Element.<PartyDetails>builder()
            .id(UUID.randomUUID()).value(respondent4).build();
        Element<PartyDetails> wrappedRespondent5 = Element.<PartyDetails>builder()
            .id(UUID.randomUUID()).value(respondent5).build();
        Element<PartyDetails> wrappedRespondent6 = Element.<PartyDetails>builder()
            .id(UUID.randomUUID()).value(respondent6).build();
        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);
        respondentList.add(wrappedRespondent2);
        respondentList.add(wrappedRespondent3);
        respondentList.add(wrappedRespondent4);
        respondentList.add(wrappedRespondent5);
        respondentList.add(wrappedRespondent6);

        List<Element<PartyDetails>> respondentList1 = new ArrayList<>();
        Element<PartyDetails> wrappedRespondent1Changed = Element.<PartyDetails>builder()
            .id(wrappedRespondent1.getId()).value(respondent1.toBuilder().phoneNumber("1234567890")
                                                      .email("test@sd.com")
                                                      .address(Address.builder()
                                                                   .addressLine1("addresdsd2").build())
                                                      .build()).build();
        respondentList1.add(wrappedRespondent1Changed);
        Element<PartyDetails> wrappedRespondent2Changed = Element.<PartyDetails>builder()
            .id(wrappedRespondent2.getId()).value(respondent2.toBuilder().phoneNumber("1234567890")
                                                      .email("test@sd.com")
                                                      .address(Address.builder()
                                                                   .addressLine1("addresdsd2").build())
                                                      .build()).build();
        respondentList1.add(wrappedRespondent2Changed);
        Element<PartyDetails> wrappedRespondent3Changed = Element.<PartyDetails>builder()
            .id(wrappedRespondent3.getId()).value(respondent3.toBuilder().phoneNumber("1234567890")
                                                      .email("test@sd.com")
                                                      .address(Address.builder()
                                                                   .addressLine1("addresdsd2").build())
                                                      .build()).build();
        respondentList1.add(wrappedRespondent3Changed);
        Element<PartyDetails> wrappedRespondent4Changed = Element.<PartyDetails>builder()
            .id(wrappedRespondent4.getId()).value(respondent4.toBuilder().phoneNumber("1234567890")
                                                      .email("test@sd.com")
                                                      .address(Address.builder()
                                                                   .addressLine1("addresdsd2").build())
                                                      .build()).build();
        respondentList1.add(wrappedRespondent4Changed);
        Element<PartyDetails> wrappedRespondent5Changed = Element.<PartyDetails>builder()
            .id(wrappedRespondent5.getId()).value(respondent5.toBuilder().phoneNumber("1234567890")
                                                      .email("test@sd.com")
                                                      .address(Address.builder()
                                                                   .addressLine1("addresdsd2").build())
                                                      .build()).build();
        respondentList1.add(wrappedRespondent5Changed);
        Element<PartyDetails> wrappedRespondent6Changed = Element.<PartyDetails>builder()
            .id(wrappedRespondent6.getId()).value(respondent6.toBuilder().phoneNumber("1234567890")
                                                      .email("test@sd.com")
                                                      .address(Address.builder()
                                                                   .addressLine1("addresdsd2").build())
                                                      .build()).build();
        respondentList1.add(wrappedRespondent6Changed);

        List<Element<ResponseDocuments>> respDoclist = new ArrayList<>();
        respDoclist.add(Element.<ResponseDocuments>builder()
                            .id(UUID.randomUUID())
                            .value(ResponseDocuments.builder()
                                       .respondentC8Document(Document.builder().build())
                                       .respondentC8DocumentWelsh(Document.builder().build())
                                       .build())
                            .build());
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondents(respondentList)
            .respondentC8Document(RespondentC8Document.builder()
                                      .respondentAc8Documents(respDoclist).build())
            .build();
        CaseData caseDataChanged = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondents(respondentList1)
            .build();
        Map<String, Object> stringObjectMap = caseData.toMap(new ObjectMapper());
        Map<String, Object> stringObjectMap1 = caseDataChanged.toMap(new ObjectMapper());
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        when(objectMapper.convertValue(stringObjectMap1, CaseData.class)).thenReturn(caseDataChanged);
        Map<String, Object> nocMap = Map.of("some", "stuff");
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, true);
        when(noticeOfChangePartiesService.generate(caseData, CARESPONDENT)).thenReturn(nocMap);
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        Map<String, Object> summaryTabFields = Map.of(
            "field4", "value4",
            "field5", "value5"
        );
        when(caseSummaryTabService.updateTab(caseData)).thenReturn(summaryTabFields);
        when(c100RespondentSolicitorService.populateDataMap(Mockito.any(), Mockito.any(), Mockito.anyString()))
            .thenReturn(dataMap);
        when(documentGenService
                 .generateSingleDocument(Mockito.any(), Mockito.any(), Mockito.any(),
                                         Mockito.anyBoolean(), Mockito.anyMap()
                 ))
            .thenReturn(Document.builder().build());
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .state(State.CASE_ISSUED.getValue())
                             .data(stringObjectMap)
                             .build())
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(stringObjectMap1)
                                   .build())
            .build();
        DocumentLanguage documentLanguage = DocumentLanguage.builder().isGenEng(true).isGenWelsh(true).build();
        when(documentLanguageService.docGenerateLang(Mockito.any(CaseData.class))).thenReturn(documentLanguage);
        updatePartyDetailsService.updateApplicantRespondentAndChildData(callbackRequest, BEARER_TOKEN);
        assertNotNull("respondents");
    }

    @Test
    void checkIfDetailsChangedFl401All() {
        PartyDetails respondentBefore = PartyDetails.builder()
            .email("test")
            .address(Address.builder()
                         .addressLine1("test")
                         .build())
            .phoneNumber("01234")
            .build();
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("FL401")
            .respondentsFL401(respondentBefore)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        PartyDetails respondent = PartyDetails.builder()
            .email("test1")
            .address(Address.builder()
                         .addressLine1("test1")
                         .build())
            .phoneNumber("012345")
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedFl401EmailOnly() {
        PartyDetails respondentBefore = PartyDetails.builder()
            .email("test")
            .build();
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("FL401")
            .respondentsFL401(respondentBefore)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        PartyDetails respondent = PartyDetails.builder()
            .email("test1")
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedFl401AddressOnly() {
        PartyDetails respondentBefore = PartyDetails.builder()
            .address(Address.builder()
                         .addressLine1("test")
                         .build())
            .build();
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("FL401")
            .respondentsFL401(respondentBefore)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        PartyDetails respondent = PartyDetails.builder()
            .address(Address.builder()
                         .addressLine1("test1")
                         .build())
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedPhoneOnly() {
        PartyDetails respondentBefore = PartyDetails.builder()
            .phoneNumber("01234")
            .build();
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("FL401")
            .respondentsFL401(respondentBefore)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        PartyDetails respondent = PartyDetails.builder()
            .phoneNumber("012345")
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedFl401NoChange() {
        PartyDetails respondentBefore = PartyDetails.builder()
            .build();
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("FL401")
            .respondentsFL401(respondentBefore)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        PartyDetails respondent = PartyDetails.builder()
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(false, bool);
    }

    @Test
    void checkIfDetailsChangedC100All() {
        UUID uuid = UUID.fromString("1afdfa01-8280-4e2c-b810-ab7cf741988a");
        PartyDetails respondentBefore = PartyDetails.builder()
            .partyId(uuid)
            .email("test")
            .address(Address.builder()
                         .addressLine1("test")
                         .build())
            .phoneNumber("01234")
            .build();
        Element<PartyDetails> wrappedRespondentBefore = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        List<Element<PartyDetails>> listOfRespondents = List.of(wrappedRespondentBefore);
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("C100")
            .respondents(listOfRespondents)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        respondentBefore = respondentBefore.toBuilder()
            .email("test1")
            .address(Address.builder()
                         .addressLine1("test1")
                         .build())
            .phoneNumber("012345")
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedC100EmailOnly() {
        UUID uuid = UUID.fromString("1afdfa01-8280-4e2c-b810-ab7cf741988a");
        PartyDetails respondentBefore = PartyDetails.builder()
            .partyId(uuid)
            .email("test")
            .build();
        Element<PartyDetails> wrappedRespondentBefore = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        List<Element<PartyDetails>> listOfRespondents = List.of(wrappedRespondentBefore);
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("C100")
            .respondents(listOfRespondents)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        respondentBefore = respondentBefore.toBuilder()
            .email("test1")
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedC100AddressOnly() {
        UUID uuid = UUID.fromString("1afdfa01-8280-4e2c-b810-ab7cf741988a");
        PartyDetails respondentBefore = PartyDetails.builder()
            .partyId(uuid)
            .address(Address.builder()
                         .addressLine1("test")
                         .build())
            .build();
        Element<PartyDetails> wrappedRespondentBefore = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        List<Element<PartyDetails>> listOfRespondents = List.of(wrappedRespondentBefore);
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("C100")
            .respondents(listOfRespondents)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        respondentBefore = respondentBefore.toBuilder()
            .address(Address.builder()
                         .addressLine1("test1")
                         .build())
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedC100PhoneOnly() {
        UUID uuid = UUID.fromString("1afdfa01-8280-4e2c-b810-ab7cf741988a");
        PartyDetails respondentBefore = PartyDetails.builder()
            .partyId(uuid)
            .phoneNumber("01234")
            .build();
        Element<PartyDetails> wrappedRespondentBefore = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        List<Element<PartyDetails>> listOfRespondents = List.of(wrappedRespondentBefore);
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("C100")
            .respondents(listOfRespondents)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        respondentBefore = respondentBefore.toBuilder()
            .phoneNumber("012345")
            .build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondent
        );
        assertEquals(true, bool);
    }

    @Test
    void checkIfDetailsChangedC100NoChange() {
        UUID uuid = UUID.fromString("1afdfa01-8280-4e2c-b810-ab7cf741988a");
        PartyDetails respondentBefore = PartyDetails.builder()
            .partyId(uuid)
            .phoneNumber("01234")
            .build();
        Element<PartyDetails> wrappedRespondentBefore = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        List<Element<PartyDetails>> listOfRespondents = List.of(wrappedRespondentBefore);
        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication("C100")
            .respondents(listOfRespondents)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails
                                   .builder()
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        boolean bool = updatePartyDetailsService.checkIfConfidentialityDetailsChangedRespondent(
            caseDataBefore,
            wrappedRespondentBefore
        );
        assertEquals(false, bool);
    }

    @Test
    void testUpdateApplicantRespondentAndChildDataCaseTypeEmpty() {
        CaseData caseData = CaseData.builder().build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(State.CASE_ISSUED.getValue())
                                   .data(objectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .data(objectMap)
                             .state(State.CASE_ISSUED.getValue())
                             .build())
            .build();
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(objectMapper.convertValue(objectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> updatedCaseData = updatePartyDetailsService
            .updateApplicantRespondentAndChildData(callbackRequest, "test");
        assertNotNull(updatedCaseData);
    }


    @Test
    void testAmendOtherPeopleInTheCase() {
        CaseData caseData = CaseData.builder().build();
        Map<String, Object> objectMap = new HashMap<>();
        objectMap.put("caseTypeOfApplication", "C100");
        CallbackRequest callbackRequest = CallbackRequest.builder().caseDetails(CaseDetails.builder()
                                                                                    .data(objectMap)
                                                                                    .build())
            .caseDetailsBefore(CaseDetails.builder()
                                   .data(objectMap)
                                   .build())
            .build();
        doNothing().when(partyLevelCaseFlagsService)
            .amendCaseFlags(
                Mockito.eq(Map.of("caseTypeOfApplication", "C100")),
                Mockito.eq(Map.of("caseTypeOfApplication", "C100")),
                Mockito.isNull());
        Map<String, Object> updatedCaseData = updatePartyDetailsService.amendOtherPeopleInTheCase(callbackRequest);
        assertNotNull(updatedCaseData);
    }

    @Test
    void testGenerateC8DocsAllRespondents() {
        UUID uuid = UUID.fromString("1afdfa01-8280-4e2c-b810-ab7cf741988a");
        PartyDetails respondentBefore = PartyDetails.builder()
            .partyId(uuid)
            .phoneNumber("01234")
            .response(Response.builder().build())
            .build();
        Element<PartyDetails> wrappedRespondentBefore = Element.<PartyDetails>builder().id(uuid).value(respondentBefore).build();
        List<Element<PartyDetails>> listOfRespondents = new ArrayList<>();
        listOfRespondents.add(wrappedRespondentBefore);
        listOfRespondents.add(wrappedRespondentBefore);
        listOfRespondents.add(wrappedRespondentBefore);
        listOfRespondents.add(wrappedRespondentBefore);
        listOfRespondents.add(wrappedRespondentBefore);
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication("C100")
            .respondents(listOfRespondents)
            .respondentC8Document(RespondentC8Document.builder().build())
            .citizenResponseDocuments(CitizenResponseDocuments.builder()
                                          .respondentAc8(ResponseDocuments.builder().build())
                                          .respondentBc8(ResponseDocuments.builder().build())
                                          .respondentCc8(ResponseDocuments.builder().build())
                                          .respondentDc8(ResponseDocuments.builder().build())
                                          .respondentEc8(ResponseDocuments.builder().build())
                                          .build())
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetails(CaseDetails.builder()
                             .id(123L)
                             .data(objectMap)
                             .state(State.CASE_ISSUED.getValue())
                             .build())
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(123L)
                                   .data(objectMap)
                                   .state(State.CASE_ISSUED.getValue())
                                   .build())
            .build();
        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);
        when(objectMapper.convertValue(objectMap, CaseData.class)).thenReturn(caseData);
        when(objectMapper.convertValue(objectMap, CaseData.class)).thenReturn(caseData);
        Map<String, Object> updatedCaseData = updatePartyDetailsService
            .updateApplicantRespondentAndChildData(callbackRequest, "test");
        assertNotNull(updatedCaseData);
    }

    @Test
    void testSetApplicantDefaultApplicant() {


        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().value(respondent2).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);
        respondentList.add(wrappedRespondent2);
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondents(respondentList)
            .build();
        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyApplicantForC100(caseData);
        assertNotNull(updatedCaseData.get("applicants"));
    }


    @Test
    void testSetApplicantDefaultApplicant_scenario2() {
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().value(respondent2).build();

        List<Element<PartyDetails>> applicantsList = new ArrayList<>();
        applicantsList.add(wrappedRespondent1);
        applicantsList.add(wrappedRespondent2);
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantsList)
            .build();
        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyApplicantForC100(caseData);
        assertNotNull(updatedCaseData.get("applicants"));
    }

    @Test
    void testSetRespondentsDefaultApplicant() {


        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().value(respondent2).build();

        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent1);
        respondentList.add(wrappedRespondent2);
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondents(respondentList)
            .build();
        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyRespondentForC100(caseData);
        assertNotNull(updatedCaseData.get("respondents"));
    }

    @Test
    void testSetRespondentsDefaultApplicant_scenario2() {
        PartyDetails respondent1 = PartyDetails.builder()
            .firstName("respondent1")
            .lastName("lastname1")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        PartyDetails respondent2 = PartyDetails.builder()
            .firstName("respondent2")
            .lastName("lastname222")
            .canYouProvideEmailAddress(YesOrNo.No)
            .isAddressConfidential(YesOrNo.No)
            .isPhoneNumberConfidential(YesOrNo.No)
            .build();

        Element<PartyDetails> wrappedRespondent1 = Element.<PartyDetails>builder().value(respondent1).build();
        Element<PartyDetails> wrappedRespondent2 = Element.<PartyDetails>builder().value(respondent2).build();

        List<Element<PartyDetails>> applicantsList = new ArrayList<>();
        applicantsList.add(wrappedRespondent1);
        applicantsList.add(wrappedRespondent2);
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .applicants(applicantsList)
            .build();
        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyRespondentForC100(caseData);
        assertNotNull(updatedCaseData.get("respondents"));
    }

    @Test
    void testSetDefaultEmptyForChildDetails_whenChildDetailsPresent() {
        Child child1 = Child.builder()
            .firstName("Test")
            .lastName("Name1")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Child child2 = Child.builder()
            .firstName("Test")
            .lastName("Name2")
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .applicantsRelationshipToChild(specialGuardian)
            .respondentsRelationshipToChild(father)
            .childLiveWith(Collections.singletonList(anotherPerson))
            .parentalResponsibilityDetails("test")
            .build();

        Element<Child> wrappedChild1 = Element.<Child>builder().value(child1).build();
        Element<Child> wrappedChild2 = Element.<Child>builder().value(child2).build();

        List<Element<Child>> childList = new ArrayList<>();
        childList.add(wrappedChild1);
        childList.add(wrappedChild2);

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .children(childList)
            .build();
        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyChildDetails(caseData);
        assertEquals(childList, updatedCaseData.get("children"));
    }

    @Test
    void testSetDefaultEmptyChildDetails_whenNoChildDetailsPresent() {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .build();

        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyChildDetails(caseData);
        List<Element<Child>> updatedChildDetails = (List<Element<Child>>) updatedCaseData.get("children");
        assertEquals(1, updatedChildDetails.size());
        assertEquals(Child.builder().build(), updatedChildDetails.get(0).getValue());
    }

    @Test
    void testSetDefaultEmptyForChildDetails_whenRevisedChildDetailsPresent() {
        ChildDetailsRevised child1 = ChildDetailsRevised.builder()
            .firstName("Test")
            .lastName("Name1")
            .dateOfBirth(LocalDate.of(2000, 12, 22))
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .parentalResponsibilityDetails("test")
            .whoDoesTheChildLiveWith(DynamicList.builder().listItems(new ArrayList<>()).build())
            .build();

        ChildDetailsRevised child2 = ChildDetailsRevised.builder()
            .firstName("Test")
            .lastName("Name2")
            .dateOfBirth(LocalDate.of(2000, 12, 22))
            .gender(female)
            .orderAppliedFor(Collections.singletonList(childArrangementsOrder))
            .parentalResponsibilityDetails("test")
            .build();

        Element<ChildDetailsRevised> wrappedChild1 = Element.<ChildDetailsRevised>builder().value(child1).build();
        Element<ChildDetailsRevised> wrappedChild2 = Element.<ChildDetailsRevised>builder().value(child2).build();

        List<Element<ChildDetailsRevised>> childList = new ArrayList<>();
        childList.add(wrappedChild1);
        childList.add(wrappedChild2);

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .taskListVersion(PrlAppsConstants.TASK_LIST_VERSION_V3)
            .newChildDetails(childList)
            .build();
        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyChildDetails(caseData);
        assertNotNull(updatedCaseData.get("newChildDetails"));
    }

    @Test
    void testSetDefaultEmptyChildDetails_whenNoRevisedChildDetailsPresent() {
        PartyDetails applicant = PartyDetails.builder().firstName("test").build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant).build();
        List<Element<PartyDetails>> applicantList = new ArrayList<>();
        applicantList.add(wrappedApplicant);

        PartyDetails respondent = PartyDetails.builder().firstName("test")
            .address(Address
                         .builder()
                         .build()).lastName("test").build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent);

        PartyDetails otherParties = PartyDetails.builder().firstName("test")
            .address(Address.builder().addressLine1("test").build()).lastName("test").build();
        Element<PartyDetails> wrappedOtherParties = Element.<PartyDetails>builder().value(otherParties).build();
        PartyDetails otherParties2 = PartyDetails.builder().firstName("test")
            .address(Address.builder().addressLine1("test").addressLine2("test").build()).lastName("test").build();
        Element<PartyDetails> wrappedOtherParties2 = Element.<PartyDetails>builder().value(otherParties2).build();
        PartyDetails otherParties3 = PartyDetails.builder().firstName("test")
            .address(Address.builder().addressLine1("test").postCode("test").build()).lastName("test").build();
        Element<PartyDetails> wrappedOtherParties3 = Element.<PartyDetails>builder().value(otherParties3).build();
        List<Element<PartyDetails>> otherPartiesList = new ArrayList<>();
        PartyDetails otherParties4 = PartyDetails.builder().firstName("test")
            .address(Address.builder().addressLine1("test").postCode("test").addressLine2("test").build()).lastName(
                "test").build();
        Element<PartyDetails> wrappedOtherParties4 = Element.<PartyDetails>builder().value(otherParties4).build();
        otherPartiesList.add(wrappedOtherParties);
        otherPartiesList.add(wrappedOtherParties2);
        otherPartiesList.add(wrappedOtherParties3);
        otherPartiesList.add(wrappedOtherParties4);

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .taskListVersion(PrlAppsConstants.TASK_LIST_VERSION_V2)
            .applicants(applicantList)
            .respondents(respondentList)
            .otherPartyInTheCaseRevised(otherPartiesList)
            .build();

        Map<String, Object> updatedCaseData = updatePartyDetailsService.setDefaultEmptyChildDetails(caseData);
        List<Element<ChildDetailsRevised>> updatedChildDetails = (List<Element<ChildDetailsRevised>>) updatedCaseData.get(
            "newChildDetails");
        assertEquals(1, updatedChildDetails.size());
    }


    @Test
    void testUpdateOtherPeopleInTheCaseConfidentialityData() {
        PartyDetails applicant = PartyDetails.builder().firstName("test").build();
        Element<PartyDetails> wrappedApplicant = Element.<PartyDetails>builder().value(applicant).build();
        List<Element<PartyDetails>> applicantList = new ArrayList<>();
        applicantList.add(wrappedApplicant);

        PartyDetails respondent = PartyDetails.builder().firstName("test")
            .address(Address
                         .builder()
                         .build()).lastName("test").build();
        Element<PartyDetails> wrappedRespondent = Element.<PartyDetails>builder().value(respondent).build();
        List<Element<PartyDetails>> respondentList = new ArrayList<>();
        respondentList.add(wrappedRespondent);

        PartyDetails otherParties = PartyDetails.builder().firstName("test")
            .dateOfBirth(LocalDate.of(1976, 7, 7)).isDateOfBirthKnown(YesOrNo.Yes)
            .placeOfBirth("birthPlace").isPlaceOfBirthKnown(YesOrNo.Yes).isCurrentAddressKnown(YesOrNo.Yes)
            .liveInRefuge(YesOrNo.Yes).refugeConfidentialityC8Form(Document.builder().build())
            .isAddressConfidential(YesOrNo.Yes)
            .canYouProvideEmailAddress(YesOrNo.Yes)
            .isEmailAddressConfidential(YesOrNo.Yes)
            .canYouProvidePhoneNumber(YesOrNo.Yes)
            .isPhoneNumberConfidential(YesOrNo.Yes)
            .phoneNumber("1234567890")
            .address(Address.builder().addressLine1("test").build()).lastName("test").build();
        Element<PartyDetails> wrappedOtherParties = Element.<PartyDetails>builder().value(otherParties).build();
        PartyDetails otherParties2 = PartyDetails.builder().firstName("test")
            .liveInRefuge(YesOrNo.No)
            .refugeConfidentialityC8Form(Document.builder().build())
            .address(Address.builder().addressLine1("test").addressLine2("test").build()).lastName("test").build();
        Element<PartyDetails> wrappedOtherParties2 = Element.<PartyDetails>builder().value(otherParties2).build();
        PartyDetails otherParties3 = PartyDetails.builder().firstName("test")
            .address(Address.builder().addressLine1("test").postCode("test").build()).lastName("test").build();
        Element<PartyDetails> wrappedOtherParties3 = Element.<PartyDetails>builder().value(otherParties3).build();
        List<Element<PartyDetails>> otherPartiesList = new ArrayList<>();
        PartyDetails otherParties4 = PartyDetails.builder().firstName("test")
            .address(Address.builder().addressLine1("test").postCode("test").addressLine2("test").build()).lastName(
                "test").build();
        Element<PartyDetails> wrappedOtherParties4 = Element.<PartyDetails>builder().value(otherParties4).build();
        otherPartiesList.add(wrappedOtherParties);
        otherPartiesList.add(wrappedOtherParties2);
        otherPartiesList.add(wrappedOtherParties3);
        otherPartiesList.add(wrappedOtherParties4);

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .taskListVersion(PrlAppsConstants.TASK_LIST_VERSION_V2)
            .applicants(applicantList)
            .respondents(respondentList)
            .otherPartyInTheCaseRevised(otherPartiesList)
            .build();
        Map<String, Object> objectMap = new HashMap<>();
        objectMap.put("caseTypeOfApplication", "C100");
        CallbackRequest callbackRequest = CallbackRequest.builder().caseDetails(CaseDetails.builder()
                                                                                    .data(objectMap).id(1L)
                                                                                    .createdDate(LocalDateTime.now())
                                                                                    .lastModified(LocalDateTime.now())
                                                                                    .build())
            .caseDetailsBefore(CaseDetails.builder()
                                   .data(objectMap)
                                   .id(1L)
                                   .createdDate(LocalDateTime.now())
                                   .lastModified(LocalDateTime.now())
                                   .build())
            .eventId(HISTORICAL_DOC_TO_RETAIN_FOR_EVENTS[0])
            .build();
        Map<String, Object> stringObjectMap = callbackRequest.getCaseDetailsBefore().getData();
        when(objectMapper.convertValue(stringObjectMap, CaseData.class)).thenReturn(caseData);
        when(objectMapper.convertValue(objectMap, CaseData.class)).thenReturn(caseData);

        RefugeConfidentialDocumentsRecord refugeConfidentialDocumentsRecord = new RefugeConfidentialDocumentsRecord(
            List.of(element(
                RefugeConfidentialDocuments.builder().build())),
            List.of(element(RefugeConfidentialDocuments.builder().build()))
        );
        when(confidentialityC8RefugeService.processC8RefugeDocumentsOnAmendForC100(
            caseData, caseData, HISTORICAL_DOC_TO_RETAIN_FOR_EVENTS[0])).thenReturn(
            refugeConfidentialDocumentsRecord);
        doNothing().when(partyLevelCaseFlagsService).amendCaseFlags(
            Mockito.anyMap(),
            Mockito.anyMap(),
            Mockito.anyString()
        );
        Map<String, Object> updatedCaseData = updatePartyDetailsService.updateOtherPeopleInTheCaseConfidentialityData(
            callbackRequest);
        assertNotNull(updatedCaseData);

    }

    @Test
    void testPopulateC8DocumentsWhenPartyIndexIsZero() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().respondentAc8Documents(new ArrayList<>(List.of(element(
                ResponseDocuments.builder().dateTimeCreated(LocalDateTime.now()).build())))).build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        when(documentLanguageService.docGenerateLang(caseData)).thenReturn(DocumentLanguage.builder().isGenWelsh(true).build());
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, true, 0, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(dataMap);
        assertNotNull(updatedCaseData.get("respondentAc8Documents"));
    }

    @Test
    void testPopulateC8DocumentsWhenPartyIndexIsOne() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().respondentBc8Documents(new ArrayList<>(List.of(element(
                ResponseDocuments.builder().dateTimeCreated(LocalDateTime.now()).build())))).build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        when(documentLanguageService.docGenerateLang(caseData)).thenReturn(DocumentLanguage.builder().isGenWelsh(false).build());
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, true, 1, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(dataMap);
        assertNotNull(updatedCaseData.get("respondentBc8Documents"));
    }

    @Test
    void testPopulateC8DocumentsWhenPartyIndexIsTwo() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().respondentCc8Documents(new ArrayList<>(List.of(element(
                ResponseDocuments.builder().dateTimeCreated(LocalDateTime.now()).build())))).build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, false, 2, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(dataMap);
        assertNotNull(updatedCaseData.get("respondentCc8Documents"));
    }

    @Test
    void testPopulateC8DocumentsWhenPartyIndexIsThree() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().respondentDc8Documents(new ArrayList<>(List.of(element(
                ResponseDocuments.builder().dateTimeCreated(LocalDateTime.now()).build())))).build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        when(documentLanguageService.docGenerateLang(caseData)).thenReturn(DocumentLanguage.builder().build());
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, true, 3, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(dataMap);
        assertNotNull(updatedCaseData.get("respondentDc8Documents"));
    }

    @Test
    void testPopulateC8DocumentsWhenPartyIndexIsFour() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().respondentEc8Documents(new ArrayList<>(List.of(element(
                ResponseDocuments.builder().dateTimeCreated(LocalDateTime.now()).build())))).build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, false, 4, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(dataMap);
        assertNotNull(updatedCaseData.get("respondentEc8Documents"));
    }

    @Test
    void testPopulateC8DocumentsWhenPartyIndexIsNotValid() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().respondentEc8Documents(new ArrayList<>(List.of(element(
                ResponseDocuments.builder().dateTimeCreated(LocalDateTime.now()).build())))).build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, false, 5, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertEquals(0,updatedCaseData.size());

        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, false, -1, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertEquals(0,updatedCaseData.size());
    }

    @Test
    void testPopulateC8DocumentsWhenThereAreNoRespondentC8Documents() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.C100_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        when(documentLanguageService.docGenerateLang(caseData)).thenReturn(DocumentLanguage.builder().isGenEng(true).build());

        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put(IS_CONFIDENTIAL_DATA_PRESENT, new ArrayList<>());
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, true, 1, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(updatedCaseData.get("respondentBc8Documents"));
        assertEquals(1, ((ArrayList) updatedCaseData.get("respondentBc8Documents")).size());
    }

    @Test
    void testPopulateC8DocumentsWhenThereIsNoConfendentialData() throws Exception {
        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(PrlAppsConstants.FL401_CASE_TYPE)
            .respondentC8Document(RespondentC8Document.builder().build())
            .build();
        when(manageOrderService.getLoggedInUserType("authToken")).thenReturn("testUser");
        Map<String, Object> updatedCaseData = new HashMap<>();
        Map<String, Object> dataMap = new HashMap<>();
        updatePartyDetailsService.populateC8Documents(
            "authToken", updatedCaseData, caseData, dataMap, true, 1, element(
                PartyDetails.builder().firstName("firstName").lastName("lastName").build())
        );
        assertNotNull(updatedCaseData.get("respondentBc8Documents"));
        assertEquals(Collections.emptyList(), (updatedCaseData.get("respondentBc8Documents")));
    }

    @ParameterizedTest
    @CsvSource({"PREPARE_FOR_HEARING_CONDUCT_HEARING, 1", "DECISION_OUTCOME, 1", "SUBMITTED_PAID, 0", "CASE_ISSUED, 0", "JUDICIAL_REVIEW, 0" })
    void shouldInvokeGenerateC8DocumentsForApplicantOnlyInHearingStates(State state, int times) throws Exception {
        PartyDetails applicant = PartyDetails.builder().firstName("App").build();
        PartyDetails respondent = PartyDetails.builder().firstName("Resp").build();
        RespondentC8Document respondentC8Document = RespondentC8Document.builder().build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(FL401_CASE_TYPE)
            .applicantsFL401(applicant)
            .respondentsFL401(respondent)
            .respondentC8Document(respondentC8Document)
            .build();

        Map<String,Object> objectMap = new HashMap<>();

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(uk.gov.hmcts.reform.ccd.client.model.CaseDetails.builder()
                                   .id(123L)
                                   .state(state.name())
                                   .data(objectMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(12345L)
                             .data(objectMap)
                             .state(state.name())
                             .build())
            .build();

        when(confidentialDetailsMapper.mapConfidentialData(
            Mockito.any(CaseData.class),
            Mockito.anyBoolean()
        )).thenReturn(caseData);

        when(objectMapper.convertValue(objectMap, CaseData.class)).thenReturn(caseData);


        Map<String, Object> updatedCaseData = updatePartyDetailsService
            .updateApplicantRespondentAndChildData(callbackRequest, "test");

        assertNotNull(updatedCaseData);
        verify(documentGenService, Mockito.times(times)).createUpdatedCaseDataWithDocuments(anyString(), any(CaseData.class));
    }

    @Test
    void shouldReturnEmptyValidateUpdatePartyDetailsIfBarristerPresentAndApplicantIsNotRemoveForC100() {
        Element<PartyDetails> applicant1 = getPartyDetails("App1", true);
        Element<PartyDetails> applicant2 = getPartyDetails("App2", true);

        Element<PartyDetails> respondent = getPartyDetails("Resp", true);

        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1, applicant2))
            .respondents(List.of(respondent))
            .build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1, applicant2))
            .respondents(List.of(respondent))
            .build();


        Map<String,Object> caseDataMapBefore = new HashMap<>();
        Map<String,Object> caseDataMap = new HashMap<>();
        caseDataMapBefore.put("before", true);
        caseDataMap.put("before", false);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(12345L)
                                   .data(caseDataMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(12345L)
                             .data(caseDataMap)
                             .build())
            .build();

        when(objectMapper.convertValue(anyMap(), eq(CaseData.class)))
            .thenAnswer(invocation -> {
                Map<String, Object> map = invocation.getArgument(0);
                if (map.get("before").equals(true)) {
                    return caseDataBefore;
                } else if (map.get("before").equals(false)) {
                    return caseData;
                }
                return null;
            });

        List<String> validationErrorList = updatePartyDetailsService.validateUpdatePartyDetails(callbackRequest);

        assertTrue(validationErrorList.isEmpty());

    }

    @Test
    void shouldReturnEmptyValidateUpdatePartyDetailsIfNoBarristerAndApplicantIsRemoveForC100() {
        Element<PartyDetails> applicant1 = getPartyDetails("App1", false);
        Element<PartyDetails> applicant2 = getPartyDetails("App2", false);

        Element<PartyDetails> respondent = getPartyDetails("Resp", false);

        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1, applicant2))
            .respondents(List.of(respondent))
            .build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1))
            .respondents(List.of(respondent))
            .build();


        Map<String,Object> caseDataMapBefore = new HashMap<>();
        Map<String,Object> caseDataMap = new HashMap<>();
        caseDataMapBefore.put("before", true);
        caseDataMap.put("before", false);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(12345L)
                                   .data(caseDataMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(12345L)
                             .data(caseDataMap)
                             .build())
            .build();

        when(objectMapper.convertValue(anyMap(), eq(CaseData.class)))
            .thenAnswer(invocation -> {
                Map<String, Object> map = invocation.getArgument(0);
                if (map.get("before").equals(true)) {
                    return caseDataBefore;
                } else if (map.get("before").equals(false)) {
                    return caseData;
                }
                return null;
            });

        List<String> validationErrorList = updatePartyDetailsService.validateUpdatePartyDetails(callbackRequest);

        assertTrue(validationErrorList.isEmpty());

    }

    @Test
    void shouldReturnValidateUpdatePartyDetailsIfBarristerPresentAndApplicantIsRemovedForC100() {
        Element<PartyDetails> applicant1 = getPartyDetails("App1", true);
        Element<PartyDetails> applicant2 = getPartyDetails("App2", true);

        Element<PartyDetails> respondent = getPartyDetails("Resp", true);

        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1, applicant2))
            .respondents(List.of(respondent))
            .build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1))
            .respondents(List.of(respondent))
            .build();

        Map<String,Object> caseDataMapBefore = new HashMap<>();
        Map<String,Object> caseDataMap = new HashMap<>();
        caseDataMapBefore.put("before", true);
        caseDataMap.put("before", false);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(12345L)
                                   .data(caseDataMapBefore)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(12345L)
                             .data(caseDataMap)
                             .build())
            .build();

        when(objectMapper.convertValue(anyMap(), eq(CaseData.class)))
            .thenAnswer(invocation -> {
                Map<String, Object> map = invocation.getArgument(0);
                if (map.get("before").equals(true)) {
                    return caseDataBefore;
                } else if (map.get("before").equals(false)) {
                    return caseData;
                }
                return null;
            });


        List<String> validationErrorList = updatePartyDetailsService.validateUpdatePartyDetails(callbackRequest);

        assertTrue(!validationErrorList.isEmpty());
        assertTrue(validationErrorList.getFirst().contains("Barrister is associated with the party"));

    }


    @Test
    void shouldReturnValidateUpdatePartyDetailsIfBarristerPresentAndRespondentIsRemovedForC100() {
        Element<PartyDetails> applicant1 = getPartyDetails("App1", true);
        Element<PartyDetails> applicant2 = getPartyDetails("App2", true);

        Element<PartyDetails> respondent1 = getPartyDetails("Resp1", true);
        Element<PartyDetails> respondent2 = getPartyDetails("Resp2", true);

        CaseData caseDataBefore = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1, applicant2))
            .respondents(List.of(respondent1, respondent2))
            .build();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(C100_CASE_TYPE)
            .applicants(List.of(applicant1, respondent2))
            .respondents(List.of(respondent1))
            .build();

        Map<String,Object> caseDataMapBefore = new HashMap<>();
        Map<String,Object> caseDataMap = new HashMap<>();
        caseDataMapBefore.put("before", true);
        caseDataMap.put("before", false);

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(12345L)
                                   .data(caseDataMapBefore)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(12345L)
                             .data(caseDataMap)
                             .build())
            .build();

        when(objectMapper.convertValue(anyMap(), eq(CaseData.class)))
            .thenAnswer(invocation -> {
                Map<String, Object> map = invocation.getArgument(0);
                if (map.get("before").equals(true)) {
                    return caseDataBefore;
                } else if (map.get("before").equals(false)) {
                    return caseData;
                }
                return null;
            });


        List<String> validationErrorList = updatePartyDetailsService.validateUpdatePartyDetails(callbackRequest);

        assertTrue(!validationErrorList.isEmpty());
        assertTrue(validationErrorList.getFirst().contains("Barrister is associated with the party"));

    }

    @Test
    void shouldReturnEmptyValidateUpdatePartyDetailsForFL401() {
        PartyDetails applicant = getPartyDetails("App1", true).getValue();
        PartyDetails respondent = getPartyDetails("Resp", true).getValue();

        CaseData caseData = CaseData.builder()
            .caseTypeOfApplication(FL401_CASE_TYPE)
            .applicantsFL401(applicant)
            .respondentsFL401(respondent)
            .build();

        Map<String,Object> caseDataMap = new HashMap<>();

        CallbackRequest callbackRequest = CallbackRequest.builder()
            .caseDetailsBefore(CaseDetails.builder()
                                   .id(12345L)
                                   .data(caseDataMap)
                                   .build())
            .caseDetails(CaseDetails.builder()
                             .id(12345L)
                             .data(caseDataMap)
                             .build())
            .build();

        when(objectMapper.convertValue(caseDataMap, CaseData.class)).thenReturn(caseData);

        List<String> validationErrorList = updatePartyDetailsService.validateUpdatePartyDetails(callbackRequest);

        assertTrue(validationErrorList.isEmpty());

    }

    private Element<PartyDetails> getPartyDetails(String partyName, boolean hasBarrister) {
        return Element.<PartyDetails>builder().id(UUID.randomUUID())
            .value(PartyDetails.builder()
                       .barrister(hasBarrister ? Barrister.builder()
                                      .barristerEmail("test1@test.com")
                                      .build() : null)
                       .firstName(partyName).build())
            .build();
    }

}
