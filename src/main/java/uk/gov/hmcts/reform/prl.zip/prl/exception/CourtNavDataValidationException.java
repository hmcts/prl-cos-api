package uk.gov.hmcts.reform.prl.exception;

public class CourtNavDataValidationException extends RuntimeException {

    public CourtNavDataValidationException(String message) {
        super(message);
    }
}
