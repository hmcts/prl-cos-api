package uk.gov.hmcts.reform.prl.exception;

public class InvalidSolicitorRoleException extends RuntimeException {
    public InvalidSolicitorRoleException(String message) {
        super(message);
    }
}
