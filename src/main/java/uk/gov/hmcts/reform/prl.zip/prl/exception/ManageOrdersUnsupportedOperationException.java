package uk.gov.hmcts.reform.prl.exception;

public class ManageOrdersUnsupportedOperationException extends UnsupportedOperationException {
    public ManageOrdersUnsupportedOperationException(String message) {
        super(message);
    }
}
