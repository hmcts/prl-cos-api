package uk.gov.hmcts.reform.prl.exception;

public class BulkPrintException extends RuntimeException {
    public BulkPrintException(String message) {
        super(message);
    }
}
