package uk.gov.hmcts.reform.prl.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@JsonSerialize(using = CustomEnumSerializer.class)
public enum ProceedingsEnum {

    @JsonProperty("ongoing")
    ongoing("ongoing", "Ongoing"),
    @JsonProperty("previous")
    previous("previous", "Previous");

    private final String id;
    private final String displayedValue;

    @JsonValue
    public String getDisplayedValue() {
        return displayedValue;
    }

    @JsonCreator
    public static ProceedingsEnum getValue(String key) {
        return ProceedingsEnum.valueOf(key);
    }

}
