package uk.gov.hmcts.reform.prl.exception;

public class GrantCaseAccessException extends RuntimeException {

    public GrantCaseAccessException(String message) {
        super(message);
    }
}
