package uk.gov.hmcts.reform.prl.exception;

public class HearingManagementValidationException extends RuntimeException {

    public HearingManagementValidationException(String message) {
        super(message);
    }
}

