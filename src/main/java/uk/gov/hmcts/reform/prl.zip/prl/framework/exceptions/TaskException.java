package uk.gov.hmcts.reform.prl.framework.exceptions;

public class TaskException extends RuntimeException {

    public TaskException(String message) {
        super(message);
    }
}
